<?php

/**
* The service that display the timezone in particular format.
*
*/

namespace  Drupal\custom_timezone;
use Drupal\Core\Datetime\DrupalDateTime;

class TimeZoneServices {
    /**
    * Function that display the timezone in particular format.
    *
    */
    public function  displayTimeZone($data = ''){
    $city       = $data['City'];
    $country    = $data['Country'];
    $timezone   = $data['TimeZone'];
    $time       = new DrupalDateTime();
    $time->setTimezone(new \DateTimeZone($timezone));

    $zoneTime   = $time->format("h:i a");
    $zoneDate   = $time->format("l, jS F Y");
    $zoneFormat = $time->format('e');
    $time_format= 'Time in '.$city.', '.date_default_timezone_get().', '.$country;   // Since the city code is not found displaying the default time zone.
    $time_data  = array('time' => $zoneTime, 'date' => $zoneDate, 'city_coutry' => $time_format);
    return $time_data;
 }

}
