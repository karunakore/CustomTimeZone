<?php  
/**  
 * @file  
 * Contains Drupal\custom_timezone\Form\CustomForm.  
 */  
namespace Drupal\custom_timezone\Form;  
use Drupal\Core\Form\ConfigFormBase;  
use Drupal\Core\Form\FormStateInterface;  
  
class CustomForm extends ConfigFormBase {  
/**  
   * Calling the config method 
   */  
  protected function getEditableConfigNames() {  
    return [  
      'custom_timezone.adminsettings',  
    ];  
  }  

   /**  
   * {@inheritdoc}  
   */  
  public function getFormId() {  
    return 'custom_form';  
  }  

  /**  
   * Build Form method  
   */  
  public function buildForm(array $form, FormStateInterface $form_state) { 
    $config = $this->config('custom_timezone.adminsettings');  

    $form['custom_timezone_label'] = [  
        '#type' => 'label',  
        '#title' => $this->t('Admin Cofiguration Form'),    
        '#description' => '==================================',
        '#default_value' => $config->get('custom_timezone_label'),  
      ];

    $form['custom_timezone_country'] = [  
      '#type' => 'textfield',  
      '#title' => $this->t('Country'),    
        '#description' => 'Enter the Country.',
        '#default_value' => $config->get('custom_timezone_country'),  
    ];  
  
    $form['custom_timezone_city'] = [  
        '#type' => 'textfield',  
        '#title' => $this->t('City'),    
        '#description' => 'Enter the City.',
        '#default_value' => $config->get('custom_timezone_city'),  
      ];  
    
      $form['custom_timezone_list'] = array(
        '#title' => t('Timezone'),
        '#type' => 'select',
        '#description' => 'Select Timezone.',
        '#options' => array('0'=> t('--- Select Timezone ---'), 
                            'America/Chicago'   => t('America/Chicago'), 
                            'America/New_York'  => t('America/New_York'), 
                            'Asia/Tokyo'        => t('Asia/Tokyo'),
                            'Asia/Dubai'        => t('Asia/Dubai'), 
                            'Asia/Kolkata'      => t('Asia/Kolkata'), 
                            'Europe/Amsterdam'  => t('Europe/Amsterdam'), 
                            'Europe/Oslo'       => t('Europe/Oslo'),
                            'Europe/London'     => t('Europe/London')),
      );
    return parent::buildForm($form, $form_state);  
  } 
  
   /**  
   * Validate Form method  
   */ 
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if(strlen($form_state->getValue('custom_timezone_city')) < 1) {
      $form_state->setErrorByName('custom_timezone_city', $this->t('Please enter city'));
    }
    if(strlen($form_state->getValue('custom_timezone_country')) < 1) {
      $form_state->setErrorByName('custom_timezone_country', $this->t('Please enter country'));
    }
    //print_r($form_state->getValue('custom_timezone_list')); exit;
    if($form_state->getValue('custom_timezone_list') == '0') {
      $form_state->setErrorByName('custom_timezone_list', $this->t('Please select the timezone'));
    }
  }

   /**  
   * Submit Form method  
   */ 
  public function submitForm(array &$form, FormStateInterface $form_state) {

      $data = array('City'=>$form_state->getValue('custom_timezone_city'), 'Country'=>$form_state->getValue('custom_timezone_country'),'TimeZone'=>$form_state->getValue('custom_timezone_list'));
      
      //call service in form
      $timezoneResult = \Drupal::service('custom_timezone.display_timezone')->displayTimeZone($data); 
      // Passing only the timezone as this is required as per requirement
      foreach ($timezoneResult as $key => $value) {
      \Drupal::messenger()->addMessage($value);
      }
    }
}  